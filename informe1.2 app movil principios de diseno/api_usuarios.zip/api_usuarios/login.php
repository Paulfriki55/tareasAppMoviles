<?php
require_once 'config.php';
require 'vendor/autoload.php';

use Firebase\JWT\JWT;

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->email) || !isset($data->password)) {
        http_response_code(400);
        echo json_encode(["message" => "Email and password are required"]);
        exit();
    }

    $email = $data->email;
    $password = $data->password;

    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id, password FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $token = JWT::encode(['id' => $user['id'], 'email' => $email], JWT_SECRET, 'HS256');
            echo json_encode(["message" => "Login successful", "token" => $token]);
        } else {
            http_response_code(401);
            echo json_encode(["message" => "Invalid credentials"]);
        }
    } else {
        http_response_code(401);
        echo json_encode(["message" => "Invalid credentials"]);
    }

    $stmt->close();
    $conn->close();
}