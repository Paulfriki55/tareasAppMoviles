<?php
require_once 'config.php';
require 'vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Content-Type: application/json");

function getAuthorizationHeader(){
    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER["Authorization"]);
    } else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
            $headers = trim($requestHeaders['Authorization']);
        }
    }
    return $headers;
}

function getBearerToken() {
    $headers = getAuthorizationHeader();
    if (!empty($headers)) {
        if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
            return $matches[1];
        }
    }
    return null;
}

function authenticate() {
    $token = getBearerToken();
    if (!$token) {
        return false;
    }

    try {
        $decoded = JWT::decode($token, new Key(JWT_SECRET, 'HS256'));
        return $decoded->id;
    } catch (Exception $e) {
        return false;
    }
}

$userId = authenticate();
if (!$userId) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$conn = getDBConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $stmt = $conn->prepare("SELECT id, email, nombre, apellido, telefono FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode($result->fetch_assoc());
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        $updateFields = [];
        $types = "";
        $params = [];

        if (isset($data->email)) {
            $updateFields[] = "email = ?";
            $types .= "s";
            $params[] = $data->email;
        }
        if (isset($data->nombre)) {
            $updateFields[] = "nombre = ?";
            $types .= "s";
            $params[] = $data->nombre;
        }
        if (isset($data->apellido)) {
            $updateFields[] = "apellido = ?";
            $types .= "s";
            $params[] = $data->apellido;
        }
        if (isset($data->telefono)) {
            $updateFields[] = "telefono = ?";
            $types .= "s";
            $params[] = $data->telefono;
        }

        if (!empty($updateFields)) {
            $sql = "UPDATE usuarios SET " . implode(", ", $updateFields) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $types .= "i";
            $params[] = $userId;
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            echo json_encode(["message" => "User updated successfully"]);
        } else {
            echo json_encode(["message" => "No fields to update"]);
        }
        break;

    case 'DELETE':
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        echo json_encode(["message" => "User deleted successfully"]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["message" => "Method not allowed"]);
        break;
}

$conn->close();