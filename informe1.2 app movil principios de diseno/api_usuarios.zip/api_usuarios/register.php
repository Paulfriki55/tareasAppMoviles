<?php
require_once 'config.php';
require 'vendor/autoload.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->email) || !isset($data->password)) {
        http_response_code(400);
        echo json_encode(["message" => "Email and password are required"]);
        exit();
    }

    $email = $data->email;
    $password = $data->password;
    $nombre = $data->nombre ?? null;
    $apellido = $data->apellido ?? null;
    $telefono = $data->telefono ?? null;

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $conn = getDBConnection();
    $stmt = $conn->prepare("INSERT INTO usuarios (email, password, nombre, apellido, telefono) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $email, $hashedPassword, $nombre, $apellido, $telefono);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(["message" => "User registered successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["message" => "Error registering user"]);
    }

    $stmt->close();
    $conn->close();
}